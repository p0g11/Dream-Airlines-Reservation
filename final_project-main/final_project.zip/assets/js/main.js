function myFunct() {
  $("div > #paragp").fadeToggle(1000);
}
